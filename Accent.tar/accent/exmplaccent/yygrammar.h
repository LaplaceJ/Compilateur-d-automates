#ifndef YYSTYPE
#define YYSTYPE long
#endif
extern YYSTYPE yylval;
extern long yypos;

#define NUMBER 256
